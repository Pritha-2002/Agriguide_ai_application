package com.example.agriguideai;

import android.app.Activity;

public class imageslider extends Activity {

}
