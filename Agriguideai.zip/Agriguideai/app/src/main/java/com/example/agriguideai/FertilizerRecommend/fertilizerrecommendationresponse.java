package com.example.agriguideai.FertilizerRecommend;

public interface fertilizerrecommendationresponse {
    void onResponse(String response);
}
