package com.example.agriguideai.CropRecommend;

public interface croprecommendationresponse {
    void onResponse(String response);
}
