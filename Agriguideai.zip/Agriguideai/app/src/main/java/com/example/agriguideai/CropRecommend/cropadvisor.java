package com.example.agriguideai.CropRecommend;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.agriguideai.Cultivation;
import com.example.agriguideai.R;


public class cropadvisor extends AppCompatActivity {

    private EditText nitrovalue;
    private EditText potasvalue;
    private EditText phosvalue;
    private EditText tempvalue;
    private EditText humivalue;
    private EditText phvalue;
    private EditText rain;
    private Button cultibtn;
    private TextView label;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cropadvisor);

        Button predict = findViewById(R.id.predictBtn);

        predict.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                nitrovalue = findViewById(R.id.nitrovalue);
                potasvalue = findViewById(R.id.potasvalue);
                phosvalue = findViewById(R.id.phosvalue);
                tempvalue = findViewById(R.id.tempvalue);
                humivalue = findViewById(R.id.humivalue);
                phvalue = findViewById(R.id.phvalue);
                rain = findViewById(R.id.rainvalue);
                label = findViewById(R.id.label);

                String N = nitrovalue.getText().toString();
                String P = phosvalue.getText().toString();
                String K = potasvalue.getText().toString();
                String temperature = tempvalue.getText().toString();
                String humidity = humivalue.getText().toString();
                String ph = phvalue.getText().toString();
                String rainfall = rain.getText().toString();

                new CropRecommendation("http://192.168.43.74:5000/recomend_crop?" + "N=" + N + "&" + "P=" + P + "&" + "K=" + K + "&" + "temperature=" + temperature + "&" + "humidity=" + humidity + "&" + "ph=" + ph + "&" + "rainfall=" + rainfall, new croprecommendationresponse() {

                    @Override
                    public void onResponse(String response) {
                        Log.i("Response Body", response);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // Toast.makeText(cropadvisor.this, response, Toast.LENGTH_SHORT).show();

                                label.setText("Recommend Crop : " + response);
                            }
                        });
                    }
                }).execute();
            }
        });

        Button cultivation = findViewById(R.id.cultBtn);
        cultivation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myintent = new Intent(cropadvisor.this, Cultivation.class);
                startActivity(myintent);

            }
        });

    }
}
